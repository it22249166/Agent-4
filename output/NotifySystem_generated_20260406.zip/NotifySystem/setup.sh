#!/bin/bash
# ── setup.sh ─────────────────────────────────────────────────────
# Project: NotifySystem | Strategy: EVENT_DRIVEN_COMPOSE
set -e

echo "======================================================"
echo "  Setup: NotifySystem"
echo "  Deployment strategy: EVENT_DRIVEN_COMPOSE"
echo "======================================================"

# Check Docker
command -v docker &>/dev/null || { echo "ERROR: Install Docker Desktop first."; exit 1; }

# Copy .env
[ ! -f .env ] && cp .env.example .env && echo "Created .env — edit passwords before starting!"


# Python venv
if [ ! -d backend/venv ]; then
  echo "Setting up Python environment..."
  cd backend && python3 -m venv venv
  source venv/bin/activate && pip install -q -r requirements.txt
  deactivate && cd ..
fi





echo ""
echo "Start with:"
echo "  docker compose up --build"
echo ""
echo "Production:"
echo "  docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d"

echo "======================================================"