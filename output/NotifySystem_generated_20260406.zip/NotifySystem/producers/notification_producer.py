import pika, json, logging, os
logger=logging.getLogger(__name__)
class NotificationProducer:
    def __init__(self): self.url=os.getenv('RABBITMQ_URL','amqp://guest:guest@rabbitmq/')
    def produce(self,routing_key:str,payload:dict):
        c=pika.BlockingConnection(pika.URLParameters(self.url))
        ch=c.channel()
        ch.exchange_declare(exchange='notifications',exchange_type='topic')
        ch.basic_publish(exchange='notifications',routing_key=routing_key,body=json.dumps(payload),properties=pika.BasicProperties(delivery_mode=2))
        c.close()
        logger.info(f'Published to {routing_key}')
