from producers.notification_producer import NotificationProducer
class EventHandler:
    def __init__(self): self.producer=NotificationProducer()
    def handle(self,event:str,data:dict):
        if event=='user.registered': self.producer.produce('notify.email',{'to':data['email'],'subject':'Welcome'})
        elif event=='order.placed':  self.producer.produce('notify.email',{'to':data['email'],'subject':'Order confirmed'})
