from fastapi import FastAPI, BackgroundTasks
import pika, json, logging, os
logging.basicConfig(level=logging.INFO)
app=FastAPI(title='Notify API')
@app.post('/notify/email')
async def email(payload:dict,bg:BackgroundTasks):
    bg.add_task(_publish,'notify.email',payload)
    return {'status':'queued'}
def _publish(rk:str,data:dict):
    c=pika.BlockingConnection(pika.URLParameters(os.getenv('RABBITMQ_URL','amqp://guest:guest@rabbitmq/')))
    ch=c.channel()
    ch.exchange_declare(exchange='notifications',exchange_type='topic')
    ch.basic_publish(exchange='notifications',routing_key=rk,body=json.dumps(data),properties=pika.BasicProperties(delivery_mode=2))
    c.close()
@app.get('/health')
def health(): return {'status':'ok'}
