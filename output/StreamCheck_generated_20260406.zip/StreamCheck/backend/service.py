class S: pass
