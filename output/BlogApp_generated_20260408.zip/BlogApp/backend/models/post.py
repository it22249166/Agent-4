from sqlalchemy import Column,Integer,String,DateTime,ForeignKey
from database import Base
from datetime import datetime
class Post(Base):
    __tablename__='posts'
    id=Column(Integer,primary_key=True)
    title=Column(String(200))
    author_id=Column(Integer,ForeignKey('users.id'))
    created_at=Column(DateTime,default=datetime.utcnow)
