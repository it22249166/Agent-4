import logging
from repositories.post_repository import PostRepository
logger=logging.getLogger(__name__)
class PostService:
    def __init__(self): self.repo=PostRepository()
    def get_all(self): return self.repo.find_all()
    def create(self,data:dict): return self.repo.save(data)
