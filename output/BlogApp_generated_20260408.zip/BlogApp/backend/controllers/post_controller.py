from fastapi import APIRouter
from services.post_service import PostService
router=APIRouter()
class PostController:
    def __init__(self): self.service=PostService()
    @router.get('/posts')
    def list_posts(self): return self.service.get_all()
    @router.post('/posts')
    def create_post(self,data:dict): return self.service.create(data)
