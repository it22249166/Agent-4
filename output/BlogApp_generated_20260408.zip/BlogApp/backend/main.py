from fastapi import FastAPI
import logging, os
logging.basicConfig(level=logging.INFO)
app=FastAPI(title='BlogApp')
@app.get('/health')
def health(): return {'status':'ok'}
