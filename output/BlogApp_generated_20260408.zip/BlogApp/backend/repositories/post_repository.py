from sqlalchemy.orm import Session
from models.post import Post
class PostRepository:
    def find_all(self): return []
    def save(self,data:dict): return data
