from fastapi import FastAPI
import pika, os, logging
logging.basicConfig(level=logging.INFO)
app=FastAPI(title='Notification')
@app.post('/notify')
def notify(d:dict):
    c=pika.BlockingConnection()
    ch=c.channel()
    ch.basic_publish(exchange='notifications',routing_key='email',body=str(d))
    return {'queued':True}
@app.get('/health')
def health(): return {'service':'notification','status':'ok'}
