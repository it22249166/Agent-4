from fastapi import FastAPI
from sqlalchemy import create_engine
import logging
logging.basicConfig(level=logging.INFO)
app=FastAPI(title='Product')
@app.get('/products')
def list_products(): return []
@app.get('/health')
def health(): return {'service':'product','status':'ok'}
