from fastapi import FastAPI
import os, logging
logging.basicConfig(level=logging.INFO)
app=FastAPI(title='Payment')
API_GATEWAY=os.getenv('API_GATEWAY','http://gateway:80')
@app.post('/payments')
def pay(d:dict): return {'payment_id':'pay_123','status':'ok'}
@app.get('/health')
def health(): return {'service':'payment','status':'ok'}
