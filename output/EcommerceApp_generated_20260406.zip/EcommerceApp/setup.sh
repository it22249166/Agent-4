#!/bin/bash
# ── setup.sh ─────────────────────────────────────────────────────
# Project: EcommerceApp | Strategy: KUBERNETES
set -e

echo "======================================================"
echo "  Setup: EcommerceApp"
echo "  Deployment strategy: KUBERNETES"
echo "======================================================"

# Check Docker
command -v docker &>/dev/null || { echo "ERROR: Install Docker Desktop first."; exit 1; }

# Copy .env
[ ! -f .env ] && cp .env.example .env && echo "Created .env — edit passwords before starting!"


# Python venv
if [ ! -d backend/venv ]; then
  echo "Setting up Python environment..."
  cd backend && python3 -m venv venv
  source venv/bin/activate && pip install -q -r requirements.txt
  deactivate && cd ..
fi





echo ""
echo "Kubernetes mode detected."
echo "Make sure Kubernetes is enabled in Docker Desktop."
echo ""
echo "To deploy:"
echo "  kubectl apply -f kubernetes/"
echo ""
echo "For local dev only:"
echo "  docker compose up --build"

echo "======================================================"