from fastapi import FastAPI, HTTPException
import httpx, logging, os
logging.basicConfig(level=logging.INFO)
app=FastAPI(title='Order')
PRODUCT_SERVICE_URL=os.getenv('PRODUCT_SERVICE_URL','http://product_service:8000')
PAYMENT_SERVICE_URL=os.getenv('PAYMENT_SERVICE_URL','http://payment_service:8000')
@app.post('/orders')
async def create_order(data:dict):
    async with httpx.AsyncClient() as c:
        p=await c.get(f'{PRODUCT_SERVICE_URL}/products/{data["product_id"]}')
    return {'order_id':'123','status':'pending'}
@app.get('/health')
def health(): return {'service':'order','status':'ok'}
