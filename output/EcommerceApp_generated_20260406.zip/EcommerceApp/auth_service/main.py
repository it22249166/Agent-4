from fastapi import FastAPI
import httpx, logging, os
logging.basicConfig(level=logging.INFO)
app=FastAPI(title='Auth')
SERVICE_URL=os.getenv('USER_SERVICE_URL','http://user_service:8000')
API_GATEWAY=os.getenv('API_GATEWAY','http://gateway:80')
@app.post('/auth/login')
async def login(data:dict):
    async with httpx.AsyncClient() as c:
        res=await c.post(f'{SERVICE_URL}/users/verify',json=data)
    return {'token':'jwt_here'}
@app.get('/health')
def health(): return {'service':'auth','status':'ok'}
